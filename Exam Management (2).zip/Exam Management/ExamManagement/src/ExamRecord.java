public class ExamRecord {
    private String studentName;
    private String subject;
    private int marks;

    public ExamRecord(String studentName, String subject, int marks) {
        this.studentName = studentName;
        this.subject = subject;
        this.marks = marks;
    }

    public String getStudentName() { return studentName; }
    public String getSubject() { return subject; }
    public int getMarks() { return marks; }

    public String toString() {
        return studentName + " - " + subject + ": " + marks + " marks";
    }
}
