import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddExamPage extends JFrame {
    public AddExamPage() {
        setTitle("Add Exam Marks");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon("src/Images/background.png")));
        setLayout(null);
        setIconImage(new ImageIcon("src/Images/icon.png").getImage());

        JLabel title = new JLabel("Add Exam Record");
        title.setBounds(130, 20, 200, 30);
        add(title);

        JLabel nameLabel = new JLabel("Student Name:");
        nameLabel.setBounds(50, 80, 100, 30);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(160, 80, 150, 30);
        add(nameField);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setBounds(50, 130, 100, 30);
        add(subjectLabel);

        JTextField subjectField = new JTextField();
        subjectField.setBounds(160, 130, 150, 30);
        add(subjectField);

        JLabel marksLabel = new JLabel("Marks:");
        marksLabel.setBounds(50, 180, 100, 30);
        add(marksLabel);

        JTextField marksField = new JTextField();
        marksField.setBounds(160, 180, 150, 30);
        add(marksField);

        JButton submitBtn = new JButton("Submit");
        submitBtn.setBounds(80, 240, 100, 30);
        add(submitBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(200, 240, 100, 30);
        add(backBtn);

        JLabel message = new JLabel();
        message.setBounds(100, 280, 250, 30);
        add(message);

        submitBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String subject = subjectField.getText();
                String marksStr = marksField.getText();

                if (name.isEmpty() || subject.isEmpty() || marksStr.isEmpty()) {
                    message.setText("Please fill all fields.");
                    return;
                }

                try {
                    int marks = Integer.parseInt(marksStr);
                    ExamRecord record = new ExamRecord(name, subject, marks);
                    DataStore.addRecord(record);
                    message.setText("Record added!");
                } catch (NumberFormatException ex) {
                    message.setText("Marks must be a number.");
                }
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Dashboard().setVisible(true);
            }
        });
    }
}
