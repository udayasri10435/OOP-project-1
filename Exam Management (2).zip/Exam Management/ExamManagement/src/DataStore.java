import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private static List<ExamRecord> examRecords = new ArrayList<>();

    public static void addRecord(ExamRecord record) {
        examRecords.add(record);
    }

    public static List<ExamRecord> getRecords() {
        return examRecords;
    }
}
