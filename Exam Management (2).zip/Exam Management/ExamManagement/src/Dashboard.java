import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame {
    public Dashboard() {
        setTitle("Dashboard");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon("src/Images/background.png")));
        setLayout(null);
        setIconImage(new ImageIcon("src/Images/icon.png").getImage());

        JLabel title = new JLabel("Student Exam Dashboard");
        title.setBounds(100, 30, 200, 30);
        add(title);

        JButton addExamBtn = new JButton("Add Exam Marks");
        addExamBtn.setBounds(120, 80, 150, 30);
        add(addExamBtn);

        JButton viewResultsBtn = new JButton("View Results");
        viewResultsBtn.setBounds(120, 130, 150, 30);
        add(viewResultsBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(120, 180, 150, 30);
        add(logoutBtn);

        addExamBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new AddExamPage().setVisible(true);
            }
        });

        viewResultsBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ViewResultsPage().setVisible(true);
            }
        });

        logoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login().setVisible(true);
            }
        });
    }
}
